﻿namespace ProductShop.Data
{
    public static class Configuration
    {
        public const string ConnectionString =
            @"Server=LAPTOP-PVBDT960;Database=ProductShop2025;Integrated Security=True";
    }
}