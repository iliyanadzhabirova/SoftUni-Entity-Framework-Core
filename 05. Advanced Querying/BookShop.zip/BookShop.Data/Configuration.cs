﻿namespace BookShop.Data
{
    internal class Configuration
    {
        internal static string ConnectionString
            => "Server=LAPTOP-PVBDT960;Database=BookShop;Integrated Security=True;";
    }
}
