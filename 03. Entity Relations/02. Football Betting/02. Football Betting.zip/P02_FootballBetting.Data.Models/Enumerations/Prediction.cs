﻿namespace P02_FootballBetting.Data.Models.Enumerations
{
    public enum Prediction
    {
        Home = 1,
        Away= 2,
        Draw = 3,

    }
}
